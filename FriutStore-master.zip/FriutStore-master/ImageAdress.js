export default {
    cet:require('./assets/density.png'),
    cart:require('./assets/Cart.png'),
}